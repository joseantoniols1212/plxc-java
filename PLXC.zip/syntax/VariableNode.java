package syntax;

public abstract class VariableNode extends ExpressionNode {

    public abstract String getIdentifierName();

}
