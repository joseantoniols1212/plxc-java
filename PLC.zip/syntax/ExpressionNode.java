package syntax;

import visitor.Visitor;

public abstract class ExpressionNode extends SentenceNode {
}