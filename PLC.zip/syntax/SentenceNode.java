package syntax;

import visitor.Visitor;

public abstract class SentenceNode extends Node {
}
