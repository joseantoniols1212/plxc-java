package syntax;

import visitor.Visitor;

public abstract class ConditionNode extends Node {
    public abstract void not();
}
